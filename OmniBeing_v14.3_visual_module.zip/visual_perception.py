
import numpy as np

class VisualPerception:
    def __init__(self):
        self.patterns_detected = []

    def detect_patterns(self, candle_data):
        patterns = []
        if len(candle_data) < 5:
            return []

        # مثال ساده: تشخیص الگوی سه کندل صعودی
        for i in range(len(candle_data) - 2):
            c1, c2, c3 = candle_data[i], candle_data[i+1], candle_data[i+2]
            if c1["close"] > c1["open"] and c2["close"] > c2["open"] and c3["close"] > c3["open"]:
                patterns.append({"pattern": "Three White Soldiers", "index": i})

        self.patterns_detected.extend(patterns)
        return patterns

    def visualize_summary(self):
        return [p["pattern"] for p in self.patterns_detected]
